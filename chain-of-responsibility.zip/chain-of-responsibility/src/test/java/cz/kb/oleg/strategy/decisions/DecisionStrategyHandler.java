package cz.kb.oleg.strategy.decisions;

import cz.kb.oleg.strategy.api.Strategy;
import cz.kb.oleg.strategy.decisions.dto.DecisionDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class DecisionStrategyHandler extends TestableStrategyHandler<DecisionDto, DecisionStrategy<DecisionDto>> {

    public DecisionStrategyHandler(List<DecisionStrategy<DecisionDto>> decisionStrategies) {
        super(decisionStrategies);
    }

    @Override
    protected void onException(Exception e, Strategy<DecisionDto> strategy, DecisionDto data) {
        log.info("Exception in decision: {}", e.getMessage());
    }

}
