package cz.kb.oleg.strategy;

import cz.kb.oleg.strategy.api.StrategyHandler;
import cz.kb.oleg.strategy.decisions.DecisionStrategy;
import cz.kb.oleg.strategy.decisions.DecisionStrategyHandler;
import cz.kb.oleg.strategy.decisions.dto.DecisionDto;
import cz.kb.oleg.strategy.events.EventStrategy;
import cz.kb.oleg.strategy.events.dto.EventDto;
import cz.kb.oleg.strategy.decisions.TestableStrategyHandler;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@SpringBootTest
@Slf4j
class StrategyApplicationTests {

    @Configuration
    @ComponentScan("cz.kb.oleg.strategy.decisions")
    static class DecisionConfig {
    }

    @Configuration
    @ComponentScan("cz.kb.oleg.strategy.events")
    static class EventConfig {

        @Bean
        public StrategyHandler<EventDto> eventDtoStrategyHandler(List<EventStrategy<EventDto>> eventStrategies) {
            return new TestableStrategyHandler<>(eventStrategies);
        }

    }

    @Autowired
    StrategyHandler<EventDto> eventDtoStrategyHandler;

    @Test
    void testStrategy() {
        eventDtoStrategyHandler.handle(new EventDto("one"));
    }

}
