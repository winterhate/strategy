package cz.kb.oleg.strategy.service;

import cz.kb.oleg.strategy.api.Strategy;
import cz.kb.oleg.strategy.api.StrategyHandler;
import cz.kb.oleg.strategy.api.StrategySelector;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.DisposableBean;

import java.util.concurrent.ExecutorService;

import static java.util.concurrent.Executors.*;
import static java.util.concurrent.TimeUnit.SECONDS;

@Slf4j
public class AsyncStrategyHandler<T> implements StrategyHandler<T>, DisposableBean {

    private final StrategySelector<T, ? extends Strategy<T>> strategySelector;
    private final ExecutorService executor;

    public AsyncStrategyHandler(StrategySelector<T, ? extends Strategy<T>> strategySelector) {
        this(newCachedThreadPool(), strategySelector);
    }

    public AsyncStrategyHandler(ExecutorService executor, StrategySelector<T, ? extends Strategy<T>> strategySelector) {
        this.executor = executor;
        this.strategySelector = strategySelector;
    }

    @Override
    public void handle(T data) {
        strategySelector.selectStrategies(data)
            .forEach(strategy ->
                executor.execute(() -> {
                    try {
                        strategy.handle(data);
                    } catch (Exception e) {
                        onException(e, strategy, data);
                    }
                })
            );
    }

    protected void onException(Exception e, Strategy<T> strategy, T data) {
        log.error("{}: Exception occurred while handling data: {}", strategy.getClass().getSimpleName(), e.getMessage(), e);
    }

    @Override
    public void destroy() throws Exception {
        executor.shutdown();
        if (executor.awaitTermination(20, SECONDS)) {
            log.info("AsyncStrategyHandler executor shut down gracefully.");
        } else {
            log.warn("AsyncStrategyHandler executor did not shut down in the allocated time. Forcing shutdown.");
            executor.shutdownNow();
        };
    }

}
