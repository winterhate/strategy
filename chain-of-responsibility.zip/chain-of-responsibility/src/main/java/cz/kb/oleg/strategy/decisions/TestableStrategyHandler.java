package cz.kb.oleg.strategy.decisions;

import cz.kb.oleg.strategy.api.Strategy;
import cz.kb.oleg.strategy.api.StrategyHandler;
import cz.kb.oleg.strategy.api.StrategySelector;
import cz.kb.oleg.strategy.api.TestableStrategy;
import cz.kb.oleg.strategy.service.TestableStrategySelector;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
public class TestableStrategyHandler<T, S extends TestableStrategy<T>> implements StrategyHandler<T> {

    private final StrategySelector<T, S> strategySelector;

    public TestableStrategyHandler(List<S> strategies) {
        this.strategySelector = new TestableStrategySelector<>(strategies);
    }

    @Override
    public void handle(T data) {
        strategySelector.selectStrategies(data).forEach(strategy -> {
            try {
                strategy.handle(data);
            } catch (Exception e) {
                onException(e, strategy, data);
            }
        });
    }

    protected void onException(Exception e, Strategy<T> strategy, T data) {
        log.error("{}: Exception occurred while handling data: {}", strategy.getClass().getSimpleName(), e.getMessage(), e);
    }

}
